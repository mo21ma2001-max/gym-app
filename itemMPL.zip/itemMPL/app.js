const express = require("express");
const path = require("path");

const app = express();
const itemsRoute = require("./routes/items");


app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static("public"));


app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));


app.use("/items", itemsRoute);


app.get("/", (req, res) => {
  res.redirect("/items");
});


app.use((req, res) => {
  res.status(404).send("Page not found");
});


const PORT = 8080;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});